import {
    SlashCommandBuilder,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    MessageFlags,
    PermissionFlagsBits,
    ChannelType
} from "discord.js";
import { addAIChannel, isAIChannel } from "../../utils/aiHandler.js";

const cooldowns = new Map();

export default {
    data: new SlashCommandBuilder()
        .setName("activate")
        .setDescription("Enable TuZhi AI in a channel")
        .addChannelOption(option =>
            option.setName("channel")
                .setDescription("Channel to enable AI")
                .addChannelTypes(ChannelType.GuildText) // Only allow text channels
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    cooldown: 5,

    async execute(interaction) {
        const userId = interaction.user.id;

        // Styled message builder
        const buildMessageContainer = (title, message, color, emoji) => {
            const header = new TextDisplayBuilder().setContent(`${emoji} **${title}**`);
            const body = new TextDisplayBuilder().setContent(`> ${message}`);
            return new ContainerBuilder()
                .setAccentColor(color)
                .addTextDisplayComponents(header)
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(body);
        };

        // Cooldown check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;

            if (timeLeft > 0) {
                const cooldownContainer = buildMessageContainer(
                    "Cooldown",
                    `You can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`,
                    0xFE8200,
                    "⏰"
                );

                const reply = await interaction.reply({
                    components: [cooldownContainer],
                    flags: MessageFlags.IsComponentsV2
                });

                setTimeout(() => reply.delete().catch(() => {}), 10000);
                return;
            }
        }

        cooldowns.set(userId, Date.now() + 5000);
        setTimeout(() => cooldowns.delete(userId), 5000);

        // Permission check
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            const warnContainer = buildMessageContainer(
                "Warn",
                "Only **Server Admins** can use this command!",
                0xFE8200,
                "⚠️"
            );

            const reply = await interaction.reply({
                components: [warnContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        // Get channel and validate
        const channel = interaction.options.getChannel("channel");
        
        // Additional validation to ensure it's a valid text channel
        if (!channel || channel.type !== ChannelType.GuildText) {
            const errorContainer = buildMessageContainer(
                "Error",
                "Please select a valid text channel!",
                0xFF0000,
                "❌"
            );

            const reply = await interaction.reply({
                components: [errorContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        // Check if already enabled
        if (isAIChannel(channel.id)) {
            const warnContainer = buildMessageContainer(
                "Already Active",
                `AI is already enabled in <#${channel.id}>!`,
                0xFE8200,
                "✅"
            );

            const reply = await interaction.reply({
                components: [warnContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        // Add channel
        addAIChannel(channel.id);

        // Success message
        const header = new TextDisplayBuilder().setContent(
            `🤖 **TuZhi AI Enabled!**`
        );

        const body = new TextDisplayBuilder().setContent(
            `> **Channel:** <#${channel.id}>\n` +
            `> \n` +
            `> ✅ AI will respond to all messages\n` +
            `> ✅ No need to ping the bot\n` +
            `> ✅ Server-wise memory saved\n` +
            `> \n` +
            `> Use \`/ai-remove\` to disable\n` +
            `> Use \`/clear-memory\` to reset history`
        );

        const footer = new TextDisplayBuilder().setContent(
            `**Enabled by:** ${interaction.user}`
        );

        const container = new ContainerBuilder()
            .setAccentColor(0xFE8200)
            .addTextDisplayComponents(header)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(body)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(footer);

        await interaction.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};