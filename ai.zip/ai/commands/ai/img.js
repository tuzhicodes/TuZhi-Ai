import { SlashCommandBuilder } from 'discord.js';
import { getRandomEmoji } from '../../utils/aiUtils.js';
import dotenv from 'dotenv';

dotenv.config();

export default {
    data: new SlashCommandBuilder()
        .setName('img')
        .setDescription('Generate an AI image')
        .addStringOption(option =>
            option
                .setName('prompt')
                .setDescription('What do you want to generate?')
                .setRequired(true)
        )
        .addStringOption(option =>
            option
                .setName('type')
                .setDescription('Image style/type')
                .setRequired(false)
                .addChoices(
                    { name: 'Realistic', value: 'realistic' },
                    { name: 'Anime', value: 'anime' },
                    { name: 'Cartoon', value: 'cartoon' },
                    { name: 'Abstract', value: 'abstract' },
                    { name: '3D Render', value: '3d' },
                    { name: 'Oil Painting', value: 'painting' }
                )
        ),

    async execute(interaction) {
        try {
            await interaction.deferReply();

            const prompt = interaction.options.getString('prompt');
            const type = interaction.options.getString('type') || 'realistic';

            // Build enhanced prompt based on type
            let enhancedPrompt = prompt;
            
            switch(type) {
                case 'anime':
                    enhancedPrompt = `anime style, ${prompt}, high quality anime art, detailed`;
                    break;
                case 'cartoon':
                    enhancedPrompt = `cartoon style, ${prompt}, vibrant colors, stylized`;
                    break;
                case 'abstract':
                    enhancedPrompt = `abstract art, ${prompt}, artistic, creative`;
                    break;
                case '3d':
                    enhancedPrompt = `3D render, ${prompt}, CGI, high quality 3D`;
                    break;
                case 'painting':
                    enhancedPrompt = `oil painting style, ${prompt}, artistic, classical art`;
                    break;
                default:
                    enhancedPrompt = `realistic, ${prompt}, photorealistic, high quality`;
            }

            // Try OpenAI DALL-E first
            if (process.env.OPENAI_API_KEY) {
                const imageUrl = await generateWithDALLE(enhancedPrompt, process.env.OPENAI_API_KEY);
                
                if (imageUrl) {
                    return await interaction.editReply({
                        content: `${getRandomEmoji()} Here's your **${type}** image! ${getRandomEmoji()}\n\n**Prompt:** ${prompt}`,
                        files: [imageUrl]
                    });
                }
            }

            // Fallback: Stability AI
            if (process.env.STABILITY_API_KEY) {
                const imageUrl = await generateWithStability(enhancedPrompt, process.env.STABILITY_API_KEY);
                
                if (imageUrl) {
                    return await interaction.editReply({
                        content: `${getRandomEmoji()} Here's your **${type}** image! ${getRandomEmoji()}\n\n**Prompt:** ${prompt}`,
                        files: [imageUrl]
                    });
                }
            }

            // No API keys available
            await interaction.editReply({
                content: `${getRandomEmoji()} Sorry, image generation is not configured. Please set up API keys in .env file.`
            });

        } catch (error) {
            console.error('Image generation error:', error);
            await interaction.editReply({
                content: `${getRandomEmoji()} Failed to generate image. Please try again later.`
            });
        }
    }
};

// ===== DALL-E IMAGE GENERATION =====
async function generateWithDALLE(prompt, apiKey) {
    try {
        const response = await fetch('https://api.openai.com/v1/images/generations', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: 'dall-e-3',
                prompt: prompt,
                n: 1,
                size: '1024x1024',
                quality: 'standard'
            })
        });

        if (!response.ok) {
            console.error('DALL-E API error:', response.status);
            return null;
        }

        const data = await response.json();
        return data.data[0].url;
    } catch (error) {
        console.error('DALL-E generation error:', error);
        return null;
    }
}

// ===== STABILITY AI IMAGE GENERATION =====
async function generateWithStability(prompt, apiKey) {
    try {
        const response = await fetch('https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                text_prompts: [{ text: prompt }],
                cfg_scale: 7,
                height: 1024,
                width: 1024,
                steps: 30,
                samples: 1
            })
        });

        if (!response.ok) {
            console.error('Stability API error:', response.status);
            return null;
        }

        const data = await response.json();
        const base64Image = data.artifacts[0].base64;
        
        // Convert base64 to buffer
        const buffer = Buffer.from(base64Image, 'base64');
        return { attachment: buffer, name: 'generated-image.png' };
    } catch (error) {
        console.error('Stability generation error:', error);
        return null;
    }
}