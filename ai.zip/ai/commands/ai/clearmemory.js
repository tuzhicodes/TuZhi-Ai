// ============================================
// commands/ai/clear-memory.js
// ============================================

import { SlashCommandBuilder } from "discord.js";
import { clearUserMemory } from "../../utils/aiHandler.js";

export default {
    data: new SlashCommandBuilder()
        .setName("clear-memory")
        .setDescription("Clear your AI conversation memory"),

    cooldown: 5,

    async execute(interaction) {
        try {
            const userId = interaction.user.id;
            const serverId = interaction.guild.id;

            // Clear memory
            const cleared = clearUserMemory(userId, serverId);

            if (cleared) {
                await interaction.reply({
                    content: "✅ **Memory Cleared!**\n\nTumhari AI conversation history delete ho gayi hai. Ab fresh start hoga! 🔄",
                    ephemeral: true
                });
            } else {
                await interaction.reply({
                    content: "ℹ️ Koi memory nahi thi clear karne ke liye!",
                    ephemeral: true
                });
            }

        } catch (error) {
            console.error("Clear memory error:", error);
            await interaction.reply({
                content: "❌ Error clearing memory!",
                ephemeral: true
            });
        }
    }
};