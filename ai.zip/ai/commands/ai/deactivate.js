import {
    SlashCommandBuilder,
    TextDisplayBuilder,
    ContainerBuilder,
    SeparatorBuilder,
    MessageFlags,
    PermissionFlagsBits
} from "discord.js";
import { removeAIChannel, isAIChannel } from "../../utils/aiHandler.js";

const cooldowns = new Map();

export default {
    data: new SlashCommandBuilder()
        .setName("deactivate")
        .setDescription("Disable TuZhi AI in current channel")
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    cooldown: 5,

    async execute(interaction) {
        const userId = interaction.user.id;

        const buildMessageContainer = (title, message, color, emoji) => {
            const header = new TextDisplayBuilder().setContent(`${emoji} **${title}**`);
            const body = new TextDisplayBuilder().setContent(`> ${message}`);
            return new ContainerBuilder()
                .setAccentColor(color)
                .addTextDisplayComponents(header)
                .addSeparatorComponents(new SeparatorBuilder())
                .addTextDisplayComponents(body);
        };

        // Cooldown check
        if (cooldowns.has(userId)) {
            const expirationTime = cooldowns.get(userId);
            const timeLeft = (expirationTime - Date.now()) / 1000;

            if (timeLeft > 0) {
                const cooldownContainer = buildMessageContainer(
                    "Cooldown",
                    `You can use this command again <t:${Math.floor(expirationTime / 1000)}:R>`,
                    0xFE8200,
                    "⏰"
                );

                const reply = await interaction.reply({
                    components: [cooldownContainer],
                    flags: MessageFlags.IsComponentsV2
                });

                setTimeout(() => reply.delete().catch(() => {}), 10000);
                return;
            }
        }

        cooldowns.set(userId, Date.now() + 5000);
        setTimeout(() => cooldowns.delete(userId), 5000);

        // Permission check
        if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
            const warnContainer = buildMessageContainer(
                "Warn",
                "Only **Server Admins** can use this command!",
                0xFE8200,
                "⚠️"
            );

            const reply = await interaction.reply({
                components: [warnContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        const channelId = interaction.channelId;

        // Check if AI is enabled
        if (!isAIChannel(channelId)) {
            const warnContainer = buildMessageContainer(
                "Not Active",
                "AI is not enabled in this channel!",
                0xFE8200,
                "❌"
            );

            const reply = await interaction.reply({
                components: [warnContainer],
                flags: MessageFlags.IsComponentsV2
            });

            setTimeout(() => reply.delete().catch(() => {}), 10000);
            return;
        }

        // Remove channel
        removeAIChannel(channelId);

        // Success message
        const header = new TextDisplayBuilder().setContent(
            `🤖 **TuZhi AI Disabled!**`
        );

        const body = new TextDisplayBuilder().setContent(
            `> ✅ User memories are still saved\n\n` +
            `> ❗ **Use** \`/ai-set\` to enable again`
        );

        const footer = new TextDisplayBuilder().setContent(
            `**Disabled by:** ${interaction.user}`
        );

        const container = new ContainerBuilder()
            .setAccentColor(0xFE8200)
            .addTextDisplayComponents(header)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(body)
            .addSeparatorComponents(new SeparatorBuilder())
            .addTextDisplayComponents(footer);

        await interaction.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};