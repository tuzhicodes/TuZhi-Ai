import fs from "fs";
import dotenv from "dotenv";

dotenv.config();

// ========== CONFIGURABLE BOT IDENTITY ==========
const BOT_CONFIG = {
    // Basic Info
    name: "TuZhi",
    fullName: "TuZhi Utility",
    age: 17,
    gender: "Male",
    location: "Madhya Pradesh, India",
    
    // Creator Info
    creator: "TuZhi Codes",
    creatorMention: "<@1144576489661149288>",
    youtubeChannel: "https://www.youtube.com/@TuZhiCodes",
    officialDiscord: "https://discord.gg/mnbQFftqby",
    supportDiscord: "https://discord.gg/t8DHmYvX6Q",
    
    // Personality
    personality: "friendly, helpful, funny, cool, passionate about coding",
    expertise: ["JavaScript", "Python", "Discord.js", "BDFD (Bot designer for discord)", "Node.js", "React", "math"],
    languages: ["Hinglish", "English", "हिन्दी", "বাংলা", "اُردُو", "नेपाली", "日本語", "中文", "मराठी"],
    
    // Custom Emojis - ADD YOUR SERVER EMOJIS HERE
    customEmojis: [
'<:AnimePOG:1317090196491075665>',
'<:AnimeSmile:1317090381321470053>',
'<:Anime_Cool:1317090175154651137>',
'<:Anime_girl:1317096786451632200>',
'<:Animememe6:1317097200764846181>',
'<:George_ahem:1307025676506890300>',
'<:TG_Angryfofinha:1309407476604604438>',
'<:TG_Me_iz_sad:1311650660814553218>',
'<:TG_Sadbilla:1309407839835390013>',
'<:TG_Shut_up:1311334839370383381>',
'<:TG_kannaspook:1309407281586241618>',
'<:TuZhi_Pareshan:1307025872271966320>',
'<:Tuzhi_ka_chappal:1307026760747188234>',
'<:Tuzhu_bye:1307026090761392278>',
'<:TuZhi_iz_feeling:1321336964783542282>',
'<:Tuzhu_iz_sad:1307026582510112910>',
'<:anime_animediscusted:1317089736912801885>',
'<:anime_lol:1317097221488902224>',
'<:animecry:1317089222229889044>',
'<:animethumb:1317089278018453595>',
'<:chappal_khayega:1323189323457237022>',
'<:emoji_100:1358764575033528522>',
'<:emoji_100:1358764850691702846>',
'<:emoji_100:1358765034888761360>',
'<:emoji_100:1358767981026349269>',
'<:emoji_100:1358768093014397118>',
'<:emoji_32:1309935976067498024>',
'<:emoji_94:1358766880835502180>',
'<:emoji_95:1358767813476618401>',
'<:emoji_97:1358767878739988570>',
'<:emoji_98:1358763910500712568>',
'<:emoji_98:1358767905944113234>',
'<:emoji_99:1358763969988399265>',
'<:emoji_99:1358764807171477520>',
'<:emoji_99:1358767931067994162>',
'<:k_cartoonsad:1317090576952463370>',
'<:funny:1317094720970948699>',
'<:emoji_99:1358784878270746746>'
    ]
};

// ========== FILE PATHS ==========
const FILES = {
    channels: "./data/ai/ai_channels.json",
    memory: "./data/ai/memory.json",
    serverData: "./data/ai/server_data.json"
};

// ========== CONSTANTS ==========
const COOLDOWN_TIME = 3000;
const MAX_CONTEXT = 30; 
const cooldowns = new Map();

// ========== FILE INITIALIZATION ==========
function ensureFiles() {
    try {
        if (!fs.existsSync("./data")) fs.mkdirSync("./data", { recursive: true });
        if (!fs.existsSync("./data/ai")) fs.mkdirSync("./data/ai", { recursive: true });
        
        Object.values(FILES).forEach(path => {
            if (!fs.existsSync(path)) {
                const defaultData = path.includes('channels') ? { channels: [] } : { servers: {} };
                fs.writeFileSync(path, JSON.stringify(defaultData, null, 2));
            }
        });
    } catch (error) {
        console.error("❌ File init error:", error.message);
    }
}

ensureFiles();

// ========== UTILITY FUNCTIONS ==========
const readJSON = (path, def) => {
    try {
        return fs.existsSync(path) ? JSON.parse(fs.readFileSync(path, "utf-8")) : def;
    } catch {
        return def;
    }
};

const writeJSON = (path, data) => {
    try {
        fs.writeFileSync(path, JSON.stringify(data, null, 2));
        return true;
    } catch {
        return false;
    }
};

// ========== CHANNEL MANAGEMENT ==========
export function isAIChannel(channelId) {
    return readJSON(FILES.channels, { channels: [] }).channels.includes(channelId);
}

export function addAIChannel(channelId) {
    const data = readJSON(FILES.channels, { channels: [] });
    if (!data.channels.includes(channelId)) {
        data.channels.push(channelId);
        writeJSON(FILES.channels, data);
    }
}

export function removeAIChannel(channelId) {
    const data = readJSON(FILES.channels, { channels: [] });
    data.channels = data.channels.filter(id => id !== channelId);
    writeJSON(FILES.channels, data);
}

// ========== MEMORY MANAGEMENT ==========
export function getUserContext(userId, serverId) {
    const memory = readJSON(FILES.memory, { servers: {} });
    if (!memory.servers[serverId]) memory.servers[serverId] = { users: {} };
    if (!memory.servers[serverId].users[userId]) {
        memory.servers[serverId].users[userId] = { context: [], currentTopic: null };
    }
    return memory.servers[serverId].users[userId];
}

export function addToContext(userId, serverId, role, content, topic = null) {
    const memory = readJSON(FILES.memory, { servers: {} });
    if (!memory.servers[serverId]) memory.servers[serverId] = { users: {} };
    if (!memory.servers[serverId].users[userId]) {
        memory.servers[serverId].users[userId] = { context: [], currentTopic: null };
    }
    
    const userData = memory.servers[serverId].users[userId];
    
    // Update current topic
    if (topic) {
        userData.currentTopic = topic;
    }
    
    userData.context.push({ role, content, timestamp: Date.now() });
    
    // Keep only recent messages
    if (userData.context.length > MAX_CONTEXT) {
        userData.context = userData.context.slice(-MAX_CONTEXT);
    }
    
    writeJSON(FILES.memory, memory);
}

export function clearUserMemory(userId, serverId) {
    const memory = readJSON(FILES.memory, { servers: {} });
    if (memory.servers[serverId]?.users[userId]) {
        delete memory.servers[serverId].users[userId];
        writeJSON(FILES.memory, memory);
        return true;
    }
    return false;
}

// ========== SERVER INFO ==========
export function updateServerInfo(guild) {
    try {
        const data = readJSON(FILES.serverData, { servers: {} });
        data.servers[guild.id] = {
            name: guild.name,
            members: guild.memberCount,
            updated: new Date().toISOString()
        };
        writeJSON(FILES.serverData, data);
    } catch {}
}

// ========== COOLDOWN ==========
export function isOnCooldown(userId, channelId) {
    const key = `${userId}_${channelId}`;
    const now = Date.now();
    if (cooldowns.has(key)) {
        const end = cooldowns.get(key);
        if (now < end) return Math.ceil((end - now) / 1000);
    }
    return 0;
}

export function setCooldown(userId, channelId) {
    const key = `${userId}_${channelId}`;
    cooldowns.set(key, Date.now() + COOLDOWN_TIME);
    setTimeout(() => cooldowns.delete(key), COOLDOWN_TIME + 1000);
}

export function isStopCommand(msg) {
    return ['stop', 'ruk', 'ruko', 'bas'].includes(msg.toLowerCase().trim());
}

// ========== GET SERVER EMOJIS ==========
export function getServerEmojis(guild) {
    try {
        if (!guild) return [];
        
        return guild.emojis.cache
            .filter(e => !e.animated)
            .map(e => `<:${e.name}:${e.id}>`)
            .slice(0, 10);
    } catch {
        return [];
    }
}

// ========== IMAGE PROCESSING ==========
async function processImage(attachment, apiKey, model) {
    try {
        if (!attachment.type?.startsWith('image/')) return null;
        
        const response = await fetch(attachment.url);
        const buffer = Buffer.from(await response.arrayBuffer());
        const base64 = buffer.toString('base64');
        
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;
        
        const apiResponse = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                contents: [{
                    parts: [
                        { text: "Describe this image in detail." },
                        { inline_data: { mime_type: attachment.type, data: base64 } }
                    ]
                }],
                generationConfig: { temperature: 0.7, maxOutputTokens: 300 }
            })
        });
        
        if (!apiResponse.ok) return null;
        
        const data = await apiResponse.json();
        return data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || null;
    } catch (error) {
        console.error("Image processing error:", error.message);
        return null;
    }
}

// ========== TOPIC EXTRACTION ==========
function extractTopic(message) {
    // Extract main keywords/topic from message
    const lower = message.toLowerCase();
    
    // Check for specific topics
    if (lower.includes('code') || lower.includes('programming')) return 'coding';
    if (lower.includes('bot') || lower.includes('discord')) return 'bot_development';
    if (lower.includes('javascript') || lower.includes('js')) return 'javascript';
    if (lower.includes('python')) return 'python';
    if (lower.includes('game') || lower.includes('gaming')) return 'gaming';
    if (lower.includes('help') || lower.includes('problem')) return 'help_request';
    
    // Extract first meaningful words as topic
    const words = message.split(' ').filter(w => w.length > 3);
    return words.slice(0, 2).join('_') || 'general';
}

// ========== PROMPT BUILDER WITH MEMORY FOCUS ==========
function buildPrompt(userData, needsDetail = false, serverEmojis = []) {
    const allEmojis = [...BOT_CONFIG.customEmojis, ...serverEmojis].slice(0, 15).join(', ');
    const currentTopic = userData.currentTopic;
    const hasContext = userData.context.length > 0;
    
    let prompt = `You are ${BOT_CONFIG.name}, a ${BOT_CONFIG.age}-year-old AI from ${BOT_CONFIG.location}.

IDENTITY:
- Name: ${BOT_CONFIG.name} (${BOT_CONFIG.fullName})
- Creator: ${BOT_CONFIG.creator} ${BOT_CONFIG.creatorMention}
- YouTube: ${BOT_CONFIG.youtubeChannel}
- Personality: ${BOT_CONFIG.personality}
- Expert in: ${BOT_CONFIG.expertise.join(', ')}
- Languages: ${BOT_CONFIG.languages.join(', ')}

${hasContext ? `🎯 CURRENT CONVERSATION TOPIC: ${currentTopic || 'continuing previous discussion'}

CRITICAL MEMORY RULES:
- Talking in the same language as the user
- STAY ON TOPIC! Continue the ongoing conversation
- Reference previous messages naturally
- DON'T change topic unless user clearly changes it
- Build on what was already discussed
- If it is [] then never add a link in it, just add the name. If it is () then you can add a link but not the name
- Show you remember what user said before
` : ''}

RESPONSE STYLE:
- SHORT (20-50 words) for simple questions
- DETAILED for explanations, code, tutorials
- Use these emojis naturally: ${allEmojis}
- Match user's language (Hindi/English/Hinglish)
- Be VARIED - never repeat exact phrases
- Always complete the user's request fully.
- Do not provide unnecessary or irrelevant information.
- Keep responses clear, direct, and helpful.
- If clarification is needed, ask politely before proceeding.
- Avoid making things up; stay accurate and reliable.
- Respect the user's preferences for language and format.
- Always reply in short messages.
- React genuinely to content

${needsDetail ? '\n🔥 DETAILED MODE: Provide complete, thorough responses.\n' : ''}

EXAMPLES:
User: hi
You: Hey! Kaise ho? 😊

User: mujhe tuzhi codes ka youtube channel do
You: Yelo [**TuZhi Codes**](https://www.youtube.com/@TuZhiCodes) ka youtube channel 

User: 7+5 kitna hotta hai? 
You: 7+5 hmmm?, 7+5=12 hotta hai 

User: 2- kardo 
You: Pahale 7+5=12 huaa tha to ab usme se 2- karna hai, to ab 12-2=10 rahega

User: code sikha
You: Haan bilkul! Kaunsi language seekhni hai? <:Anime_Cool:1317090175154651137>

User: [continues topic]
You: [Stay on same topic, reference previous discussion]

CRITICAL: If there's conversation history, CONTINUE that topic! Don't jump to new topics randomly!`;

    return prompt;
}

// ========== API CALL ==========
async function callGeminiAPI(prompt, needsDetail) {
    const key = process.env.AI_API_KEY;
    const model = process.env.AI_MODEL || "gemini-1.5-flash";
    
    if (!key) throw new Error("AI_API_KEY missing");

    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;

    const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: {
                temperature: 0.85,
                maxOutputTokens: needsDetail ? 2048 : 500,
                topP: 0.9,
                topK: 40
            },
            safetySettings: [
                { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_ONLY_HIGH" },
                { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_ONLY_HIGH" },
                { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
                { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_ONLY_HIGH" }
            ]
        })
    });

    if (!response.ok) {
        const err = await response.text();
        throw new Error(`API ${response.status}`);
    }

    const data = await response.json();
    
    if (data.candidates?.[0]?.content?.parts?.[0]?.text) {
        return data.candidates[0].content.parts[0].text.trim();
    }
    
    throw new Error("Invalid response");
}

// ========== MAIN GENERATOR WITH REPLY SUPPORT ==========
export async function generateAIResponse(
    message,
    userId,
    client,
    serverId,
    attachments = [],
    stickers = [],
    guild = null,
    mentionedUser = null,
    replyToMessage = null
) {
    try {
        console.log(`\n🤖 Generating for: "${message}"`);

        if (guild) updateServerInfo(guild);

        const needsDetail = checkDetailNeeded(message);
        const userData = getUserContext(userId, serverId);
        const serverEmojis = guild ? getServerEmojis(guild) : [];

        // Build enriched message
        let enrichedMsg = message || "[no text]";
        
        // ADD REPLIED MESSAGE CONTEXT
        if (replyToMessage) {
            console.log(`📧 Reply to: "${replyToMessage.content}"`);
            enrichedMsg = `[Replying to: "${replyToMessage.content.substring(0, 100)}"]\n${enrichedMsg}`;
        }
        
        // Process images
        if (attachments.length > 0) {
            console.log(`📎 Processing ${attachments.length} attachment(s)...`);
            
            for (const att of attachments.slice(0, 2)) {
                if (att.type?.startsWith('image/')) {
                    const description = await processImage(att, process.env.AI_API_KEY, process.env.AI_MODEL);
                    if (description) {
                        enrichedMsg += `\n[Image shows: ${description}]`;
                        console.log(`📸 Image analyzed`);
                    } else {
                        enrichedMsg += `\n[Image attached]`;
                    }
                } else if (att.type?.startsWith('video/')) {
                    enrichedMsg += `\n[Video: ${att.name}]`;
                } else {
                    enrichedMsg += `\n[File: ${att.name}]`;
                }
            }
        }
        
        // Add stickers
        if (stickers.length > 0) {
            enrichedMsg += `\n[Sticker: ${stickers[0].name}]`;
        }

        // Extract topic from current message
        const currentTopic = extractTopic(enrichedMsg);

        // Build conversation with FULL CONTEXT
        const systemPrompt = buildPrompt(userData, needsDetail, serverEmojis);
        let fullPrompt = systemPrompt + "\n\n";
        
        // Add ALL recent context for better memory
        if (userData.context.length > 0) {
            fullPrompt += "📚 CONVERSATION HISTORY (Remember this!):\n";
            userData.context.forEach(m => {
                fullPrompt += `${m.role === 'user' ? 'User' : 'You'}: ${m.content}\n`;
            });
            fullPrompt += "\n";
        }

        fullPrompt += `Current User Message: ${enrichedMsg}\nYour Response:`;

        console.log(`📤 Calling API... (Context: ${userData.context.length} messages, Topic: ${currentTopic})`);

        const response = await callGeminiAPI(fullPrompt, needsDetail);
        
        // Save to context WITH TOPIC
        addToContext(userId, serverId, "user", enrichedMsg, currentTopic);
        addToContext(userId, serverId, "assistant", response, currentTopic);

        console.log(`✅ Response generated! Topic maintained: ${currentTopic}`);

        return response;

    } catch (error) {
        console.error("❌ Error:", error.message);
        
        if (error.message.includes("429")) {
            return "API limit! 😅 Try after 2 minutes.";
        }
        
        if (error.message.includes("API_KEY")) {
            return "API key missing! 😅";
        }
        
        return "An error occurred! 😅 Try again. ";
    }
}

function checkDetailNeeded(msg) {
    const triggers = ['explain', 'batao', 'kaise', 'code', 'bana', 'likh', 'samjhao', 'detail', 'guide', 'tutorial'];
    return triggers.some(t => msg.toLowerCase().includes(t));
}

export function getBotIdentity() {
    return BOT_CONFIG;
}