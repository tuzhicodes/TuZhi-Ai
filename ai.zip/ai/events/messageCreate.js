import { Events } from "discord.js";
import { 
    isAIChannel, 
    generateAIResponse, 
    isStopCommand, 
    isOnCooldown, 
    setCooldown, 
    updateServerInfo 
} from "../utils/aiHandler.js";

console.log("✅ messageCreate event loaded!");

export default {
    name: Events.MessageCreate,
    
    async execute(message, client) {
        try {
            if (!message || message.author?.bot || !message.guild) return;
            
            console.log(`📨 [MSG] ${message.author.username}: "${message.content}"`);
            
            if (!isAIChannel(message.channelId)) return;

            console.log(`✅ AI channel detected!`);

            const content = message.content?.trim() || "";
            
            // Get attachments
            const attachments = [];
            if (message.attachments && message.attachments.size > 0) {
                message.attachments.forEach(att => {
                    attachments.push({
                        name: att.name,
                        url: att.url,
                        type: att.contentType,
                        size: att.size
                    });
                    console.log(`📎 Attachment: ${att.name}`);
                });
            }

            // Get stickers
            const stickers = [];
            if (message.stickers && message.stickers.size > 0) {
                message.stickers.forEach(sticker => {
                    stickers.push({
                        name: sticker.name,
                        id: sticker.id,
                        url: sticker.url
                    });
                    console.log(`🎨 Sticker: ${sticker.name}`);
                });
            }

            // Get mentioned user
            let mentionedUser = null;
            if (message.mentions?.users?.size > 0) {
                const mentions = Array.from(message.mentions.users.values());
                mentionedUser = mentions.find(u => u.id !== client.user.id);
                if (mentionedUser) {
                    console.log(`👤 Mentioned: ${mentionedUser.username}`);
                }
            }

            // 🆕 GET REPLIED MESSAGE
            let replyToMessage = null;
            if (message.reference) {
                try {
                    replyToMessage = await message.channel.messages.fetch(message.reference.messageId);
                    console.log(`📧 Replying to: "${replyToMessage.content.substring(0, 50)}..."`);
                } catch (err) {
                    console.log("⚠️ Could not fetch replied message");
                }
            }

            // Update server info
            try {
                updateServerInfo(message.guild);
            } catch (err) {}

            // Stop command
            if (isStopCommand(content)) {
                await message.reply("Okay, rukta hu! 👍").catch(() => {});
                return;
            }

            // Cooldown
            const cooldown = isOnCooldown(message.author.id, message.channelId);
            if (cooldown > 0) {
                await message.react('⏰').catch(() => {});
                return;
            }

            setCooldown(message.author.id, message.channelId);

            // Typing
            let typingInterval;
            try {
                typingInterval = setInterval(() => {
                    message.channel.sendTyping().catch(() => {});
                }, 5000);
                await message.channel.sendTyping().catch(() => {});
            } catch (err) {}

            try {
                console.log(`🤖 Generating AI response...`);
                
                const response = await generateAIResponse(
                    content,
                    message.author.id,
                    client,
                    message.guild.id,
                    attachments,
                    stickers,
                    message.guild,
                    mentionedUser,
                    replyToMessage // 🆕 Pass replied message
                );

                if (typingInterval) clearInterval(typingInterval);

                if (!response || response.length === 0) {
                    throw new Error("Empty response");
                }

                console.log(`✅ Got response (${response.length} chars)`);
                console.log(`📤 Sending...`);
                
                // DIRECT SEND - NO SPLIT
                await message.reply({
                    content: response,
                    allowedMentions: { repliedUser: false }
                });
                
                console.log(`✅ Sent successfully!`);

            } catch (error) {
                if (typingInterval) clearInterval(typingInterval);
                console.error(`❌ Error:`, error.message);
                
                try {
                    await message.reply({
                        content: "Arre yaar! 😅 Kuch problem aa gayi.",
                        allowedMentions: { repliedUser: false }
                    });
                } catch (err) {
                    await message.react('😅').catch(() => {});
                }
            }

        } catch (error) {
            console.error(`❌ Fatal:`, error.message);
        }
    }
};