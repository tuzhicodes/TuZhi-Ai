import fs from "fs";
import path from "path";
import { Client, Collection, GatewayIntentBits, REST, Routes, Partials } from "discord.js";
import { fileURLToPath } from 'url';
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.clear();
console.log(`\x1b[36m╔═══════════════════════════════════════════════════════════════════════════════╗\x1b[0m`);
console.log(`\x1b[36m║\x1b[0m                       \x1b[33m⚡ TUZHI AI SYSTEM ⚡\x1b[0m                          \x1b[36m║\x1b[0m`);
console.log(`\x1b[36m║\x1b[0m                   \x1b[32m🔥 POWERED BY TUZHI CODES 🔥\x1b[0m                          \x1b[36m║\x1b[0m`);
console.log(`\x1b[36m╚═══════════════════════════════════════════════════════════════════════════════╝\x1b[0m\n`);

const OWNER_ID = process.env.OWNER_ID;

// Error handlers
process.on("unhandledRejection", (error) => {
    console.error("❌ Unhandled Rejection:", error);
});

process.on("uncaughtException", (error) => {
    console.error("❌ Uncaught Exception:", error);
});

// Client setup
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildPresences,
    ],
    partials: [Partials.Channel, Partials.Message],
});

client.commands = new Collection();
const cooldowns = new Map();

// Helper function to get all files
function getAllFiles(dirPath, arrayOfFiles = []) {
    const files = fs.readdirSync(dirPath);

    files.forEach((file) => {
        const fullPath = path.join(dirPath, file);
        
        if (fs.statSync(fullPath).isDirectory()) {
            arrayOfFiles = getAllFiles(fullPath, arrayOfFiles);
        } else if (file.endsWith('.js')) {
            arrayOfFiles.push(fullPath);
        }
    });

    return arrayOfFiles;
}

// Load Commands
console.log("📂 Loading Commands...");
const commands = [];
const commandsPath = path.join(__dirname, 'commands');

if (fs.existsSync(commandsPath)) {
    const commandFiles = getAllFiles(commandsPath);
    
    for (const file of commandFiles) {
        try {
            const fileUrl = `file://${file}`;
            const command = await import(fileUrl);
            
            if (command.default && command.default.data) {
                client.commands.set(command.default.data.name, command.default);
                commands.push(command.default.data.toJSON());
                console.log(`   ✅ ${command.default.data.name}`);
            }
        } catch (err) {
            console.log(`   ❌ ${path.basename(file)}: ${err.message}`);
        }
    }
} else {
    console.log("   ⚠️  Commands folder not found!");
}

// Load Events
console.log("\n📂 Loading Events...");
const eventsPath = path.join(__dirname, 'events');

if (fs.existsSync(eventsPath)) {
    const eventFiles = getAllFiles(eventsPath);
    console.log(`   Found ${eventFiles.length} event file(s)`);
    
    for (const file of eventFiles) {
        try {
            const fileUrl = `file://${file}`;
            const event = await import(fileUrl);
            
            if (event.default && event.default.name) {
                const eventName = event.default.name;
                
                if (event.default.once) {
                    client.once(eventName, (...args) => event.default.execute(...args, client));
                    console.log(`   ✅ ${eventName} (once) - ${path.basename(file)}`);
                } else {
                    client.on(eventName, (...args) => event.default.execute(...args, client));
                    console.log(`   ✅ ${eventName} - ${path.basename(file)}`);
                }
            } else {
                console.log(`   ⚠️  ${path.basename(file)} - Invalid structure`);
            }
        } catch (err) {
            console.log(`   ❌ ${path.basename(file)}: ${err.message}`);
        }
    }
} else {
    console.log("   ⚠️  Events folder not found!");
}

// Register slash commands
const rest = new REST({ version: "10" }).setToken(process.env.TOKEN);
(async () => {
    try {
        console.log("\n⏳ Registering slash commands...");
        await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });
        console.log("✅ Commands registered!\n");
    } catch (error) {
        console.error("❌ Command registration failed:", error);
    }
})();

// Ready event
client.once("ready", async () => {
    console.log(`\n🎉 ${client.user.tag} is ONLINE!`);
    console.log(`📊 Servers: ${client.guilds.cache.size}`);
    console.log(`👥 Users: ${client.users.cache.size}\n`);

    console.log("🔍 Intents Check:");
    console.log(`   MessageContent: ${client.options.intents.has(GatewayIntentBits.MessageContent) ? '✅' : '❌'}`);
    console.log(`   GuildMessages: ${client.options.intents.has(GatewayIntentBits.GuildMessages) ? '✅' : '❌'}`);
    console.log(`   Guilds: ${client.options.intents.has(GatewayIntentBits.Guilds) ? '✅' : '❌'}\n`);

    // Fetch members
    for (const guild of client.guilds.cache.values()) {
        try {
            await guild.members.fetch();
        } catch {}
    }
});

// Slash command handler
client.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    // Cooldown
    const cooldownKey = `${interaction.user.id}-${interaction.commandName}`;
    const cooldownAmount = (command.cooldown || 2) * 1000;

    if (cooldowns.has(cooldownKey)) {
        const expiration = cooldowns.get(cooldownKey);
        const timeLeft = (expiration - Date.now()) / 1000;

        if (timeLeft > 0) {
            return interaction.reply({
                content: `⏳ Wait ${timeLeft.toFixed(1)}s`,
                ephemeral: true,
            }).catch(() => {});
        }
    }

    cooldowns.set(cooldownKey, Date.now() + cooldownAmount);
    setTimeout(() => cooldowns.delete(cooldownKey), cooldownAmount);

    try {
        await command.execute(interaction, OWNER_ID);
    } catch (error) {
        console.error(`❌ Error in /${interaction.commandName}:`, error.message);
        
        const msg = { content: "❌ Command error", ephemeral: true };
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp(msg).catch(() => {});
        } else {
            await interaction.reply(msg).catch(() => {});
        }
    }
});

// Status
const statuses = [
    { name: "TuZhi Codes", type: 0 },
    { name: "AI Active", type: 3 },
];

let statusIndex = 0;
setInterval(() => {
    if (client.user) {
        const status = statuses[statusIndex];
        client.user.setPresence({
            activities: [{
                name: `${status.name} | ${client.guilds.cache.size} servers`,
                type: status.type,
            }],
            status: "dnd",
        });
        statusIndex = (statusIndex + 1) % statuses.length;
    }
}, 15000);

// Login
console.log("🚀 Starting bot...\n");
client.login(process.env.TOKEN).catch((error) => {
    console.error("❌ Login failed:", error.message);
    console.error("💡 Check TOKEN in .env");
    console.error("💡 Enable MESSAGE CONTENT INTENT in Discord Portal");
});